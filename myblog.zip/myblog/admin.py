from django.contrib import admin
from .models import Input

admin.site.register(Input)